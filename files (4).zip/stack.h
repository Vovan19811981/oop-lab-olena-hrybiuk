#pragma once
// stack.h
// Шаблонний клас СТЕК на основі статичного масиву вказівників
// Завдання 9: Лабораторна робота №10 — Шаблони
//
// Операції:
//   push(T*)   — занесення елемента у стек
//   pop()      — вилучення значення з верхівки стеку
//   peek()     — перегляд верхівки без вилучення
//   print()    — виведення всіх значень на екран
//   size()     — повернення кількості елементів
//   isEmpty()  — перевірка, чи стек порожній
//   isFull()   — перевірка, чи стек повний

#include <iostream>
#include <stdexcept>
using namespace std;

template <class T, int MAX_SIZE = 100>
class Stack {
private:
    T* data[MAX_SIZE];   // статичний масив вказівників
    int top;             // індекс верхівки (-1 якщо порожній)

public:
    // Конструктор — ініціалізує порожній стек
    Stack();

    // Деструктор — не видаляє об'єкти (власником є той, хто поклав)
    ~Stack();

    // Занесення елемента у стек (передається вказівник)
    void push(T* elem);

    // Вилучення вказівника з верхівки стеку
    T* pop();

    // Перегляд верхівки без вилучення
    T* peek() const;

    // Виведення всіх значень стеку на екран (від верхівки до дна)
    void print() const;

    // Повернення поточної кількості елементів
    int size() const;

    // Перевірка чи стек порожній
    bool isEmpty() const;

    // Перевірка чи стек повний
    bool isFull() const;
};

// ─── Реалізація ───────────────────────────────────────────────

template <class T, int MAX_SIZE>
Stack<T, MAX_SIZE>::Stack() : top(-1) {}

template <class T, int MAX_SIZE>
Stack<T, MAX_SIZE>::~Stack() {
    // Вказівники залишаємо — власник відповідає за пам'ять
}

template <class T, int MAX_SIZE>
void Stack<T, MAX_SIZE>::push(T* elem) {
    if (isFull())
        throw overflow_error("Стек переповнений — неможливо додати елемент.");
    data[++top] = elem;
}

template <class T, int MAX_SIZE>
T* Stack<T, MAX_SIZE>::pop() {
    if (isEmpty())
        throw underflow_error("Стек порожній — неможливо вилучити елемент.");
    return data[top--];
}

template <class T, int MAX_SIZE>
T* Stack<T, MAX_SIZE>::peek() const {
    if (isEmpty())
        throw underflow_error("Стек порожній — немає верхівки.");
    return data[top];
}

template <class T, int MAX_SIZE>
void Stack<T, MAX_SIZE>::print() const {
    if (isEmpty()) {
        cout << "[ порожній стек ]\n";
        return;
    }
    cout << "Стек (верхівка → дно): ";
    for (int i = top; i >= 0; i--) {
        cout << *data[i];
        if (i > 0) cout << " | ";
    }
    cout << '\n';
}

template <class T, int MAX_SIZE>
int Stack<T, MAX_SIZE>::size() const {
    return top + 1;
}

template <class T, int MAX_SIZE>
bool Stack<T, MAX_SIZE>::isEmpty() const {
    return top == -1;
}

template <class T, int MAX_SIZE>
bool Stack<T, MAX_SIZE>::isFull() const {
    return top == MAX_SIZE - 1;
}
