// listing1_swap.cpp
// Шаблонна функція для обміну значень двох змінних будь-якого типу
#include <iostream>
using namespace std;

template <class X>
void swapargs(X &a, X &b) {
    X temp;
    temp = a;
    a = b;
    b = temp;
}

int main() {
    int i = 10, j = 20;
    double x = 10.1, y = 23.3;
    char a = 'x', b = 'z';

    cout << "Початкові значення i, j: " << i << ' ' << j << '\n';
    cout << "Початкові значення x, y: " << x << ' ' << y << '\n';
    cout << "Початкові значення a, b: " << a << ' ' << b << '\n';

    swapargs(i, j);
    swapargs(x, y);
    swapargs(a, b);

    cout << "Переставлені значення i, j: " << i << ' ' << j << '\n';
    cout << "Переставлені значення x, y: " << x << ' ' << y << '\n';
    cout << "Переставлені значення a, b: " << a << ' ' << b << '\n';

    return 0;
}
