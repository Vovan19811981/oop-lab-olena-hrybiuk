// main.cpp
// Завдання 9: Шаблонний клас СТЕК на статичному масиві вказівників
// Лабораторна робота №10 — Шаблони
//
// Демонстрація роботи зі стеками різних типів:
//   - Stack<int>    — стек цілих чисел
//   - Stack<double> — стек дійсних чисел
//   - Stack<string> — стек рядків

#include <iostream>
#include <string>
#include <stdexcept>
#include "stack.h"
using namespace std;

// ─── Допоміжна функція: тест з int ────────────────────────────
void testIntStack() {
    cout << "\n========== Stack<int> ==========\n";

    Stack<int, 5> s;

    int a = 10, b = 20, c = 30, d = 40, e = 50;

    s.push(&a);
    s.push(&b);
    s.push(&c);
    s.push(&d);
    s.push(&e);

    s.print();
    cout << "Розмір стеку: " << s.size() << "\n";
    cout << "Верхівка (peek): " << *s.peek() << "\n";

    cout << "Вилучення елементів:\n";
    while (!s.isEmpty()) {
        cout << "  pop → " << *s.pop() << "\n";
    }

    // Спроба вилучити з порожнього — обробка виключення
    try {
        s.pop();
    } catch (const underflow_error& e) {
        cout << "Виключення: " << e.what() << "\n";
    }

    // Переповнення стеку
    Stack<int, 2> small;
    int x = 1, y = 2, z = 3;
    small.push(&x);
    small.push(&y);
    try {
        small.push(&z);
    } catch (const overflow_error& e) {
        cout << "Виключення: " << e.what() << "\n";
    }
}

// ─── Допоміжна функція: тест з double ─────────────────────────
void testDoubleStack() {
    cout << "\n========== Stack<double> ==========\n";

    Stack<double> s;

    double vals[] = {3.14, 2.71, 1.41, 1.73, 0.577};
    const int N = sizeof(vals) / sizeof(vals[0]);

    for (int i = 0; i < N; i++)
        s.push(&vals[i]);

    s.print();
    cout << "Кількість елементів: " << s.size() << "\n";

    cout << "Вилучення трьох елементів:\n";
    for (int i = 0; i < 3; i++)
        cout << "  pop → " << *s.pop() << "\n";

    s.print();
}

// ─── Допоміжна функція: тест з string ─────────────────────────
void testStringStack() {
    cout << "\n========== Stack<string> ==========\n";

    Stack<string> s;

    string words[] = {"шаблон", "клас", "стек", "вказівник", "C++"};
    const int N = sizeof(words) / sizeof(words[0]);

    for (int i = 0; i < N; i++)
        s.push(&words[i]);

    s.print();
    cout << "Розмір: " << s.size() << "\n";

    cout << "Виштовхування всіх елементів:\n";
    while (!s.isEmpty())
        cout << "  pop → " << *s.pop() << "\n";
}

// ─── Точка входу ──────────────────────────────────────────────
int main() {
    testIntStack();
    testDoubleStack();
    testStringStack();

    cout << "\n=== Завершено ===\n";
    return 0;
}
