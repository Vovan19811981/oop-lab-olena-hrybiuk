// listing25_class_specialization.cpp
// Явна спеціалізація узагальненого класу для типу int
#include <iostream>
using namespace std;

template <class T>
class myclass {
    T x;
public:
    myclass(T a) {
        cout << "Всередині узагальненого класу\n";
        x = a;
    }
    T getx() { return x; }
};

// Спеціалізація для int — зберігає квадрат числа
template <>
class myclass<int> {
    int x;
public:
    myclass(int a) {
        cout << "Всередині спеціалізації myclass<int>\n";
        x = a * a;
    }
    int getx() { return x; }
};

int main() {
    myclass<double> d(10.1);
    cout << "double: " << d.getx() << "\n\n";

    myclass<int> i(5);
    cout << "int: " << i.getx() << "\n";

    return 0;
}
