// listing5_two_types.cpp
// Шаблонна функція з двома узагальненими типами
#include <iostream>
using namespace std;

template <class type1, typename type2>
void myfunc(type1 x, type2 y) {
    cout << x << ' ' << y << '\n';
}

int main() {
    myfunc(10, "Я вчу C++");
    myfunc(98.6, 19L);
    return 0;
}
