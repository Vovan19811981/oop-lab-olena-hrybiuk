// listing19_safe_array.cpp
// Узагальнений безпечний масив з перевантаженим оператором []
#include <iostream>
#include <cstdlib>
using namespace std;

const int SIZE = 10;

template <class AType>
class atype {
    AType a[SIZE];
public:
    atype() {
        for (int i = 0; i < SIZE; i++) a[i] = i;
    }
    AType &operator[](int i);
};

template <class AType>
AType &atype<AType>::operator[](int i) {
    if (i < 0 || i > SIZE - 1) {
        cout << "\nЗначення індекса " << i << " виходить за допустимі межі.\n";
        exit(1);
    }
    return a[i];
}

int main() {
    atype<int> intob;
    atype<double> doubleob;
    int i;

    cout << "Масив integer: ";
    for (i = 0; i < SIZE; i++) intob[i] = i;
    for (i = 0; i < SIZE; i++) cout << intob[i] << " ";
    cout << '\n';

    cout << "Масив Double: ";
    for (i = 0; i < SIZE; i++) doubleob[i] = (double)i / 3;
    for (i = 0; i < SIZE; i++) cout << doubleob[i] << " ";
    cout << '\n';

    intob[12] = 100; // вихід за межі — генерує помилку
    return 0;
}
