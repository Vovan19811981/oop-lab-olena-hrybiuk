// listing6_explicit_overload.cpp
// Явне перевантаження шаблонної функції для типу int
#include <iostream>
using namespace std;

template <class X>
void swapargs(X &a, X &b) {
    X temp;
    temp = a;
    a = b;
    b = temp;
    cout << "всередині шаблону swapargs.\n";
}

// Явна спеціалізація для int
template<>
void swapargs<int>(int &a, int &b) {
    int temp;
    temp = a;
    a = b;
    b = temp;
    cout << "Всередині спеціалізації функції swapargs для цілих\n";
}

int main() {
    int i = 10, j = 20;
    double x = 10.1, y = 23.3;
    char a = 'x', b = 'z';

    cout << "Початкові значення i, j: " << i << ' ' << j << '\n';
    cout << "Початкові значення x, y: " << x << ' ' << y << '\n';
    cout << "Початкові значення a, b: " << a << ' ' << b << '\n';

    swapargs(i, j);
    swapargs(x, y);
    swapargs(a, b);

    cout << "Переставлені значення i, j: " << i << ' ' << j << '\n';
    cout << "Переставлені значення x, y: " << x << ' ' << y << '\n';
    cout << "Переставлені значення a, b: " << a << ' ' << b << '\n';

    return 0;
}
