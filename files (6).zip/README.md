# Практична робота 6 — Події та DOM маніпуляції

> **Дисципліна:** Основи програмування мовою JavaScript  
> **Тема:** Події — обробники, делегування, DOM маніпуляції, інтерактивний UI

---

## Структура репозиторію

```
js-events/
├── README.md
├── variant1/   — Форма з live-валідацією та real-time пошуком
├── variant2/   — Custom Dropdown та Sortable Table
├── variant3/   — Modal System та Kanban Board
├── variant4/   — Tab Interface та Drawing App
├── variant5/   — Accordion та Snake Game
└── variant6/   — Notification System та Memory Card Game
```

---

## Варіант 1 — Форма з live-валідацією та пошуком

**Файл:** `variant1/index.html`

### Функціонал
- Контактна форма: ім'я, email, телефон (+380...), повідомлення (20–500 символів)
- Live-валідація з debounce 300ms
- Візуальний feedback: зелена/червона рамка + іконки ✓/✗ + текст помилки
- Прогрес-бар заповнення (0–100%)
- Submit заблокований до повної валідації
- Real-time пошук по 32 студентах з підсвічуванням `<mark>`
- "Нічого не знайдено" при відсутності результатів

---

## Варіант 2 — Custom Dropdown та Sortable Table

**Файл:** `variant2/index.html`

### Функціонал
- Single-select dropdown з пошуком (15 мов програмування)
- Multi-select dropdown з тегами (15 технологій), видалення тегів
- Keyboard navigation (↑↓ Enter Esc) для обох дропдаунів
- Закриття при кліку поза компонентом
- Таблиця 25 записів, 6 колонок
- Сортування по кожній колонці ASC/DESC зі стрілками
- Фільтри по 4 колонках (ім'я, відділ, роль, місто)
- Пагінація по 10 записів

---

## Варіант 3 — Modal System та Kanban Board

**Файл:** `variant3/index.html`

### Функціонал
- 5 типів модалів: Alert, Confirm, Prompt, Custom, стек модалів
- Анімація fade + scale, backdrop blur
- Закриття: Esc, клік на backdrop, кнопка ×
- Блокування прокрутки при відкритому модалі
- Kanban дошка: To Do / In Progress / Done
- Drag & Drop між колонками
- Додавання/видалення карток через модальні вікна
- Лічильник карток у заголовках
- Збереження стану в LocalStorage

---

## Варіант 4 — Tab Interface та Drawing App

**Файл:** `variant4/index.html`

### Функціонал
- 5 вкладок з keyboard navigation (←→)
- Lazy loading: вкладки позначаються при першому відкритті
- Збереження активної вкладки у URL hash (#tab-N)
- Canvas 900×460 для малювання
- Інструменти: олівець, ластик, лінія, прямокутник, коло
- Колір та товщина лінії
- Undo (Ctrl+Z, до 20 кроків), Clear, Save PNG
- Touch-підтримка
- Відображення координат курсору

---

## Варіант 5 — Accordion та Snake Game

**Файл:** `variant5/index.html`

### Функціонал
- 5 секцій акордеону з анімацією висоти
- Single-mode: відкрита лише одна секція
- Keyboard navigation (Enter, Space, ↑↓)
- ARIA attributes (aria-expanded, aria-controls)
- Вкладений accordion (nested)
- Snake на Canvas 300×300, сітка 20×20
- Управління: ←→↑↓ та WASD
- Рахунок, рекорд (localStorage), 3 рівні швидкості
- Рівні: 1 = кожні 5 очок
- Game Over + рестарт (R або кнопка)
- Пауза (P або кнопка)

---

## Варіант 6 — Notification System та Memory Card Game

**Файл:** `variant6/index.html`

### Функціонал
- 4 типи сповіщень: success, error, warning, info
- 4 позиції: top-right, top-left, bottom-right, bottom-left
- Автоматичне закриття з прогрес-баром таймера (4 сек)
- Ручне закриття (кнопка ×)
- Черга до 5 одночасних сповіщень
- Анімація появи (slide + scale)
- Memory Game: сітки 4×4 та 6×6
- Картки з emoji (30 унікальних)
- CSS 3D-анімація перевертання (perspective + rotateY)
- Лічильник ходів та таймер
- Рекорд (localStorage) окремо для кожного розміру сітки
- Переможний екран з результатами

---

## Запуск

Відкрити будь-який `index.html` у браузері — жодних залежностей не потрібно. Усі варіанти — чистий HTML/CSS/JS без фреймворків.

```bash
# Або через Live Server
cd variant1 && live-server
```

---

## Технічні вимоги виконано

| Вимога | Статус |
|--------|--------|
| Event delegation | ✅ Kanban (v3), таблиця (v2) |
| Keyboard navigation | ✅ v2, v4, v5 |
| ARIA attributes | ✅ v2 (listbox), v5 (accordion) |
| Адаптивний дизайн | ✅ Всі варіанти |
| CSS transitions/animations | ✅ Всі варіанти |
| Edge cases | ✅ Порожній пошук, переповнення стеку, нічия |
| LocalStorage | ✅ v3 (Kanban), v5 (рекорд), v6 (рекорд) |
