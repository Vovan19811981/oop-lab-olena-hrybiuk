/*
 * Лабораторна робота 2.4
 * Проектування і опрацювання програми
 * з власними маніпуляторами і власними функціями введення-виведення
 *
 * Компіляція: g++ -std=c++17 main.cpp -o lab24
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <limits>
#include <algorithm>
#include <cmath>
#include <stdexcept>

using namespace std;

/* ════════════════════════════════════════════════════════
 *  ВЛАСНИЙ МАНІПУЛЯТОР — замінює один символ-пробіл
 *  на табуляцію у потоці виведення
 * ════════════════════════════════════════════════════════ */
ostream& tab(ostream& stream) {
    stream << '\t';
    return stream;
}

/* ════════════════════════════════════════════════════════
 *  ВЛАСНИЙ МАНІПУЛЯТОР — скидає прапори формату
 *  і встановлює звичайний (decimal, no showpos)
 * ════════════════════════════════════════════════════════ */
ostream& resetFmt(ostream& stream) {
    stream.unsetf(ios::showpos | ios::fixed | ios::scientific);
    stream << dec;
    return stream;
}

/* ════════════════════════════════════════════════════════
 *  КЛАС MathFunction
 *  Зберігає масиви значень по осі X та Y математичної функції.
 *  Реалізує:
 *    - конструктор / деструктор
 *    - функцію вставки (operator<<) — виводить дані на екран
 *      та малює ASCII-графік
 *    - функцію вилучення (operator>>) — зчитує дані з файлу
 * ════════════════════════════════════════════════════════ */
class MathFunction {
private:
    vector<double> x;   /* значення по осі абсцис */
    vector<double> y;   /* значення по осі ординат */
    string name;        /* назва функції (для виведення) */

public:
    /* ── Конструктор ── */
    MathFunction() = default;
    explicit MathFunction(const string& funcName) : name(funcName) {}

    /* ── Деструктор ── */
    ~MathFunction() {
        x.clear();
        y.clear();
    }

    /* ── Гетери ── */
    const vector<double>& getX()    const { return x; }
    const vector<double>& getY()    const { return y; }
    const string&         getName() const { return name; }
    void                  setName(const string& n) { name = n; }

    /* ── Завантаження одного рядка ── */
    void addPoint(double xi, double yi) {
        x.push_back(xi);
        y.push_back(yi);
    }

    /* ════════════════════════════════════════
     *  Дружня функція вставки (operator<<)
     *  Виводить таблицю і ASCII-графік функції
     * ════════════════════════════════════════ */
    friend ostream& operator<<(ostream& stream, const MathFunction& f);

    /* ════════════════════════════════════════
     *  Дружня функція вилучення (operator>>)
     *  Зчитує ОДИН стовпець Y із відкритого потоку.
     *  X вже має бути заповнений (або зчитується разом).
     * ════════════════════════════════════════ */
    friend istream& operator>>(istream& stream, MathFunction& f);

    /* ════════════════════════════════════════
     *  Дружня функція: min та max по Y
     * ════════════════════════════════════════ */
    friend void printMinMax(const MathFunction& f1, const MathFunction& f2);
};

/* ──────────────────────────────────────────
 *  Реалізація функції вставки
 * ────────────────────────────────────────── */
ostream& operator<<(ostream& stream, const MathFunction& f) {
    if (f.x.empty()) {
        stream << "[" << f.name << "] Даних немає.\n";
        return stream;
    }

    /* --- Заголовок таблиці --- */
    stream << "\n╔══════════════════════════════════════╗\n";
    stream << "║  Функція: " << left << setw(27) << f.name << "║\n";
    stream << "╠══════════════════════════════════════╣\n";
    stream << "║    " << setw(12) << "x"
           << setw(12) << "y"
           << "       ║\n";
    stream << "╠══════════════════════════════════════╣\n";

    /* --- Рядки таблиці --- */
    for (size_t i = 0; i < f.x.size(); ++i) {
        stream << "║  "
               << fixed << setprecision(3)
               << setw(10) << f.x[i] << "  "
               << setw(10) << f.y[i] << "    ║\n";
    }
    stream << "╚══════════════════════════════════════╝\n";

    /* --- ASCII-графік --- */
    const int WIDTH  = 60;   /* ширина поля графіку */
    const int HEIGHT = 20;   /* висота поля графіку */

    double yMin = *min_element(f.y.begin(), f.y.end());
    double yMax = *max_element(f.y.begin(), f.y.end());
    double xMin = *min_element(f.x.begin(), f.x.end());
    double xMax = *max_element(f.x.begin(), f.x.end());

    if (yMax == yMin) yMax = yMin + 1.0;
    if (xMax == xMin) xMax = xMin + 1.0;

    /* Ініціалізуємо буфер символами пробілу */
    vector<string> canvas(HEIGHT, string(WIDTH, ' '));

    /* Вісь Y (вертикальна) */
    int axisX = static_cast<int>((0.0 - xMin) / (xMax - xMin) * (WIDTH - 1));
    axisX = max(0, min(WIDTH - 1, axisX));
    for (int row = 0; row < HEIGHT; ++row)
        canvas[row][axisX] = '|';

    /* Вісь X (горизонтальна) */
    int axisY = static_cast<int>((yMax - 0.0) / (yMax - yMin) * (HEIGHT - 1));
    axisY = max(0, min(HEIGHT - 1, axisY));
    for (int col = 0; col < WIDTH; ++col)
        canvas[axisY][col] = '-';

    /* Перетин осей */
    canvas[axisY][axisX] = '+';

    /* Нанесення точок функції */
    for (size_t i = 0; i < f.x.size(); ++i) {
        int col = static_cast<int>((f.x[i] - xMin) / (xMax - xMin) * (WIDTH - 1));
        int row = static_cast<int>((yMax - f.y[i]) / (yMax - yMin) * (HEIGHT - 1));
        col = max(0, min(WIDTH - 1, col));
        row = max(0, min(HEIGHT - 1, row));
        canvas[row][col] = '*';
    }

    /* Виведення графіку */
    stream << "\n  Графік [" << f.name << "]:\n";
    stream << "  y=" << fixed << setprecision(1) << yMax << "\n";
    for (int row = 0; row < HEIGHT; ++row) {
        stream << "  " << canvas[row] << "\n";
    }
    stream << "  y=" << yMin << "\n";
    stream << "  x=[" << xMin << " .. " << xMax << "]\n\n";

    return stream;
}

/* ──────────────────────────────────────────
 *  Реалізація функції вилучення
 *  Зчитує рядки формату: x  y1  y2
 *  f1 отримує стовпець y1, f2 — стовпець y2
 * ────────────────────────────────────────── */
istream& operator>>(istream& stream, MathFunction& f) {
    /* Ця версія зчитує пари (x, y) — використовується
       після того, як зовнішній код вже розбив рядки. */
    double xi, yi;
    f.x.clear();
    f.y.clear();
    while (stream >> xi >> yi) {
        f.x.push_back(xi);
        f.y.push_back(yi);
    }
    return stream;
}

/* ──────────────────────────────────────────
 *  Зчитування файлу з трьома стовпцями:
 *  x | y1 | y2  → два об'єкти MathFunction
 * ────────────────────────────────────────── */
void readTwoFunctions(const string& filename,
                      MathFunction& f1,
                      MathFunction& f2)
{
    ifstream fin(filename);
    if (!fin.is_open())
        throw runtime_error("Не вдалося відкрити файл: " + filename);

    f1.getX(); // просто звернення, щоб компілятор не скаржився
    double xi, y1i, y2i;
    while (fin >> xi >> y1i >> y2i) {
        f1.addPoint(xi, y1i);
        f2.addPoint(xi, y2i);
    }
    fin.close();
}

/* ──────────────────────────────────────────
 *  Дружня функція: знаходження та виведення
 *  min / max серед обох функцій
 * ────────────────────────────────────────── */
void printMinMax(const MathFunction& f1, const MathFunction& f2) {
    if (f1.y.empty() && f2.y.empty()) {
        cout << "Даних немає.\n";
        return;
    }

    double globalMin =  numeric_limits<double>::max();
    double globalMax = -numeric_limits<double>::max();
    double xAtMin = 0, xAtMax = 0;

    auto check = [&](const MathFunction& f) {
        for (size_t i = 0; i < f.y.size(); ++i) {
            if (f.y[i] < globalMin) { globalMin = f.y[i]; xAtMin = f.x[i]; }
            if (f.y[i] > globalMax) { globalMax = f.y[i]; xAtMax = f.x[i]; }
        }
    };
    check(f1);
    check(f2);

    cout << "\n┌─────────────────────────────────────┐\n";
    cout << "│  Мін / Макс серед обох функцій       │\n";
    cout << "├─────────────────────────────────────┤\n";
    cout << fixed << setprecision(3);
    cout << "│  Мінімум: y = " << setw(10) << globalMin
         << "  при x = " << setw(6) << xAtMin << "  │\n";
    cout << "│  Максимум: y = " << setw(10) << globalMax
         << "  при x = " << setw(6) << xAtMax << "  │\n";
    cout << "└─────────────────────────────────────┘\n\n";
}

/* ════════════════════════════════════════════════════════
 *  Функція конвертації файлу у форматований вигляд:
 *    - пробіли → табуляція (власний маніпулятор tab)
 *    - fixed notation, 3 знаки після коми
 *    - ширина поля 10
 *    - цілі числа → "+10.000"  (showpos + fixed)
 * ════════════════════════════════════════════════════════ */
void convertFileFormatted(const string& srcFile, const string& dstFile) {
    ifstream fin(srcFile);
    if (!fin.is_open())
        throw runtime_error("Не вдалося відкрити: " + srcFile);

    ofstream fout(dstFile);
    if (!fout.is_open())
        throw runtime_error("Не вдалося створити: " + dstFile);

    /* Встановлюємо формат для вихідного файлу */
    fout << fixed << setprecision(3) << showpos;

    double x, y1, y2;
    while (fin >> x >> y1 >> y2) {
        fout << setw(10) << x  << tab   /* власний маніпулятор */
             << setw(10) << y1 << tab
             << setw(10) << y2 << "\n";
    }

    fin.close();
    fout.close();
    cout << "Форматований файл збережено: " << dstFile << "\n";
}

/* ════════════════════════════════════════════════════════
 *  ГОЛОВНА ФУНКЦІЯ
 * ════════════════════════════════════════════════════════ */
int main() {
    /* ─── 1. Зчитування даних з файлу ─── */
    MathFunction f1("y = x^2 (квадратична)");
    MathFunction f2("y = x^3 (кубічна)");

    try {
        readTwoFunctions("data.txt", f1, f2);
    } catch (const exception& e) {
        cerr << "Помилка: " << e.what() << "\n";
        return 1;
    }

    /* ─── 2. Виведення таблиць та графіків (функція вставки) ─── */
    cout << f1;
    cout << f2;

    /* ─── 3. Мін / Макс (дружня функція) ─── */
    printMinMax(f1, f2);

    /* ─── 4. Конвертація у форматований файл ─── */
    try {
        convertFileFormatted("data.txt", "data_formatted.txt");
    } catch (const exception& e) {
        cerr << "Помилка запису: " << e.what() << "\n";
        return 1;
    }

    /* ─── 5. Виведення вмісту форматованого файлу на екран ─── */
    cout << "\n── Вміст форматованого файлу (data_formatted.txt) ──\n";
    ifstream check("data_formatted.txt");
    if (check.is_open()) {
        cout << check.rdbuf();
        check.close();
    }

    /* ─── 6. Демонстрація маніпуляторів ─── */
    cout << "\n── Демонстрація маніпуляторів ──\n";
    cout << "Звичайний виведення: " << 88 << "\n";
    cout.setf(ios::showbase | ios::hex | ios::uppercase);
    cout << "HEX+SHOWBASE: " << 88 << "\n";
    cout.unsetf(ios::uppercase);
    cout << "hex (lowercase): " << 88 << "\n";
    cout << resetFmt;        /* власний маніпулятор скидання */
    cout << "Після resetFmt: " << 88 << "\n";

    cout << "\nПрограму завершено успішно.\n";
    return 0;
}
