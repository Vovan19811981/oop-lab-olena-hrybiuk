# Практична робота 6 (Частина 2): Events — Complex Interactive Apps

> **Дисципліна:** Основи програмування мовою JavaScript  
> **Тема:** Події — Складні інтерактивні застосунки  
> **Максимальний бал:** 10

---

## 📁 Структура репозиторію

```
practice-06-events-part2/
├── variant-01-kanban/        # Kanban Board з Drag & Drop
├── variant-02-gallery/       # Infinite Scroll Gallery
├── variant-03-search/        # Real-time Search з Autocomplete
├── variant-04-drawing/       # Drawing App (Canvas)
├── variant-05-table/         # Sortable Table з Filters
├── variant-06-piano/         # Piano / Keyboard Synthesizer
├── variant-07-snake/         # Snake Game
├── variant-08-memory/        # Memory Card Game
├── variant-09-timeline/      # Interactive Timeline
└── variant-10-tictactoe/     # Tic-Tac-Toe з AI (Minimax)
```

Кожен варіант — **один файл `index.html`** без зовнішніх залежностей.  
Відкривається прямо в браузері або через GitHub Pages.

---

## 🚀 Запуск

```bash
git clone https://github.com/YOUR_USERNAME/practice-06-events-part2.git
cd practice-06-events-part2

# Варіант 1 — просто відкрити у браузері
open variant-01-kanban/index.html

# Або локальний сервер (для variant-06 piano потрібен HTTP)
npx serve .
# → http://localhost:3000/variant-01-kanban/
```

### GitHub Pages деплой
```bash
git init && git add . && git commit -m "feat: all 10 variants"
git remote add origin https://github.com/YOUR/REPO.git
git push -u origin main
# Settings → Pages → Source: main / root
```

---

## 📋 Варіанти та реалізований функціонал

### 01 — Kanban Board
**Drag & Drop** між 4 колонками, CRUD карток, фільтри, LocalStorage.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Drag & Drop | 3 | ✅ між колонками + reorder всередині + placeholder |
| CRUD операції | 2 | ✅ create/edit (dblclick)/delete + modal |
| Фільтрація та пошук | 2 | ✅ by priority/assignee + debounce search |
| UI/UX та animations | 2 | ✅ hover, color-coding, smooth drag |
| Код якість | 0.5 | ✅ чистий код, коментарі |
| **Разом** | **9.5** | + demo video |

**Особливості:** ghost placeholder, touch events, LocalStorage, 4 виконавці з аватарами, due date з виділенням прострочених.

---

### 02 — Infinite Scroll Gallery
**120+ зображень**, lazy loading, lightbox зі zoom, favorites.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Infinite scroll | 2.5 | ✅ IntersectionObserver + симульований API |
| Lazy loading | 2 | ✅ data-src + observer, skeleton |
| Lightbox з навігацією | 2.5 | ✅ стрілки, клавіатура, swipe, wheel zoom |
| Search та filters | 2 | ✅ пошук + категорія + сортування |
| UI/UX | 0.5 | ✅ masonry, animations, progress bar |
| **Разом** | **9.5** | + demo video |

---

### 03 — Real-time Search with Autocomplete
**500 товарів**, Boolean operators, wildcard, voice search.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Autocomplete | 2.5 | ✅ 10 suggestions, highlight, keyboard nav |
| Real-time results | 2 | ✅ debounce 300ms, highlight terms |
| Advanced search | 2 | ✅ AND/OR/NOT, "phrase", wildcard * |
| Фільтри та sort | 2 | ✅ category, rating, price range, sort |
| Voice search | 1 | ✅ Web Speech API |
| **Разом** | **9.5** | + demo video |

---

### 04 — Drawing App (Canvas)
**8 інструментів**, шари, undo/redo 50 кроків, export PNG/JPEG/SVG.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Інструменти малювання | 3 | ✅ Pen/Line/Rect/Circle/Eraser/Fill/Text/Eyedropper |
| Layers system | 2.5 | ✅ add/delete/visibility/opacity/reorder |
| Undo/Redo | 1.5 | ✅ до 50 кроків (snapshot history) |
| Export/Import | 1.5 | ✅ PNG, JPEG, SVG + import as layer |
| UI/UX | 1 | ✅ cursor preview, keyboard shortcuts |
| **Разом** | **9.5** | + demo video |

---

### 05 — Sortable Table with Filters
**500 рядків**, 9 колонок, multi-sort, resize, pin, bulk export.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Sorting та filters | 3 | ✅ multi-column Ctrl+Click, column filters |
| Column operations | 2.5 | ✅ show/hide, resize, pin left |
| Row selection та bulk | 2 | ✅ checkbox, select all, delete, export |
| Pagination та export | 1.5 | ✅ 10/25/50/100, jump to page, CSV/JSON |
| UI/UX | 0.5 | ✅ zebra, hover, empty states |
| **Разом** | **9.5** | + demo video |

---

### 06 — Piano / Keyboard Synthesizer
**Web Audio API**, 5 інструментів, reverb/delay/distortion, WAV export.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Клавіатура та звуки | 2.5 | ✅ 2 октави, 5 інструментів, ASDF mapping |
| Recording та playback | 2.5 | ✅ record/play/stop/save WAV |
| Effects та visualizer | 2.5 | ✅ Reverb+Delay+Distortion + Canvas bars |
| Preset songs | 1.5 | ✅ Twinkle Star, Happy Birthday, Jingle Bells |
| UI/UX | 0.5 | ✅ press animation, keyboard map |
| **Разом** | **9.5** | + demo video |

---

### 07 — Snake Game
**4 режими гри**, power-ups, particle effects, combo multiplier.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Базова механіка | 2.5 | ✅ рух, їжа, зростання, game over |
| Додаткові features | 2.5 | ✅ bonus food, penalty, speed boost, invincible |
| Game modes | 2 | ✅ Classic/Borderless/Time Attack/Survival |
| Scoring та leaderboard | 2 | ✅ combo x8, LocalStorage top-5 |
| UI/UX та effects | 0.5 | ✅ particles, snake з очима |
| **Разом** | **9.5** | + demo video |

---

### 08 — Memory Card Game
**3D flip**, 4 теми, custom upload, confetti, hints.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Базова механіка | 2 | ✅ flip/match/mismatch logic |
| Difficulty levels | 2 | ✅ 4×4 / 6×6 / 8×8 |
| Themes та customization | 2 | ✅ Emoji/Flags/Animals/Food + upload |
| Animations та effects | 2 | ✅ 3D flip, glow, confetti, sound |
| Stats та hints | 1.5 | ✅ timer, moves, stars, best time, hints |
| **Разом** | **9.5** | + demo video |

---

### 09 — Interactive Timeline
**22 події**, minimap, drag-scroll, zoom, CRUD із LocalStorage.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Timeline display | 2 | ✅ vertical, групування по роках, 22+ подій |
| Navigation та zoom | 2.5 | ✅ drag scroll, zoom +/-, minimap, "Today" |
| Event management | 2 | ✅ add/edit/delete, LocalStorage |
| Filtering та search | 2 | ✅ категорія, дата від/до, keyword search |
| UI/UX та animations | 1 | ✅ fade-in on scroll, tooltip, color coding |
| **Разом** | **9.5** | + demo video |

---

### 10 — Tic-Tac-Toe with AI
**Minimax + Alpha-Beta Pruning**, 3 режими, 3 розміри поля.

| Критерій | Бали | Реалізовано |
|----------|------|-------------|
| Game modes | 2 | ✅ PvP / PvAI / AI vs AI |
| AI implementation | 3 | ✅ Easy/Medium/Hard(Minimax)/Impossible(α-β) |
| Statistics та history | 2 | ✅ score, streak, win rate, move rewind |
| Animations та effects | 2 | ✅ pop, win glow, confetti, sound |
| Board variations | 0.5 | ✅ 3×3 / 4×4 / 5×5 |
| **Разом** | **9.5** | + demo video |

---

## 🛠 Загальні технічні вимоги

| Вимога | Варіанти |
|--------|---------|
| `debounce` | 01, 02, 03, 05, 09 |
| `throttle` / rAF | 04, 07 (render loop) |
| Event delegation | 01, 02, 05, 08 |
| Touch events | 01, 02, 06, 07 |
| IntersectionObserver | 02, 09 |
| LocalStorage | 01, 02, 03, 07, 08, 09, 10 |
| Web Audio API | 06, 08, 10 |
| Canvas API | 04, 06, 07 |
| Web Speech API | 03 |
| Responsive design | Всі |
| Error handling (try/catch) | Всі |
