#include <iostream>
#include <stdexcept>

// ============================================================
//  Клас Chislo — базовий клас із закритим полем типу long
// ============================================================
class Chislo {
private:
    long number;          // закрите ціле додатне число

public:
    // Конструктор: приймає ціле додатне число
    explicit Chislo(long n = 0) : number(n) {
        if (n < 0)
            throw std::invalid_argument("Число має бути невід'ємним!");
        std::cout << "[Chislo] Конструктор, number = " << number << "\n";
    }

    // Деструктор
    virtual ~Chislo() {
        std::cout << "[Chislo] Деструктор, number = " << number << "\n";
    }

    // Геттер (потрібен нащадкам)
    long getNumber() const { return number; }

    // Сеттер
    void setNumber(long n) {
        if (n < 0)
            throw std::invalid_argument("Число має бути невід'ємним!");
        number = n;
    }

    // Віртуальна функція: обчислює факторіал переданого числа
    virtual long factorial(long n) const {
        if (n < 0)
            throw std::invalid_argument("Факторіал від'ємного числа не існує!");
        long result = 1;
        for (long i = 2; i <= n; ++i)
            result *= i;
        return result;
    }
};

// ============================================================
//  Клас Matrix — похідний від Chislo
//  Успадковує number (розмірність масиву) і factorial()
// ============================================================
class Matrix : public Chislo {
public:
    long arr[100];        // одновимірний масив 100 цілих додатних чисел

    // Конструктор: n — розмірність масиву (зберігається у базовому класі)
    explicit Matrix(long n = 0) : Chislo(n) {
        if (n > 100)
            throw std::invalid_argument("Розмірність не може перевищувати 100!");
        // Ініціалізуємо масив нулями
        for (int i = 0; i < 100; ++i)
            arr[i] = 0;
        std::cout << "[Matrix] Конструктор, розмірність = " << n << "\n";
    }

    // Деструктор
    ~Matrix() override {
        std::cout << "[Matrix] Деструктор, розмірність = " << getNumber() << "\n";
    }

    // Віртуальну функцію factorial() НЕ перевизначаємо —
    // використовується реалізація з базового класу Chislo.
    // Аналіз: виклик через вказівник Chislo* на об'єкт Matrix
    // також використає версію Chislo::factorial(), оскільки
    // Matrix її не перевизначає.

    // Функція заповнення масиву з клавіатури
    void fillFromKeyboard() {
        long n = getNumber();
        std::cout << "Введіть " << n << " цілих додатних чисел:\n";
        for (long i = 0; i < n; ++i) {
            std::cout << "  arr[" << i << "] = ";
            std::cin >> arr[i];
            if (arr[i] < 0)
                throw std::invalid_argument("Числа мають бути невід'ємними!");
        }
    }

    // Функція обчислення факторіала кожного елементу масиву
    // тієї розмірності, що зберігається у базовому класі
    void printFactorials() const {
        long n = getNumber();
        std::cout << "\nФакторіали елементів масиву:\n";
        for (long i = 0; i < n; ++i) {
            std::cout << "  factorial(" << arr[i] << ") = "
                      << factorial(arr[i]) << "\n";   // виклик успадкованої функції
        }
    }
};

// ============================================================
//  Допоміжна функція: приймає вказівник на базовий клас,
//  обчислює та виводить факторіали елементів масиву
//  через вказівник на Chislo*
// ============================================================
void processFactorials(Chislo* ptr) {
    // Динамічне приведення: якщо ptr насправді вказує на Matrix
    Matrix* m = dynamic_cast<Matrix*>(ptr);
    if (m == nullptr) {
        // Просто обчислюємо факторіал числа базового класу
        std::cout << "Об'єкт Chislo: factorial(" << ptr->getNumber()
                  << ") = " << ptr->factorial(ptr->getNumber()) << "\n";
        return;
    }
    // Викликаємо printFactorials через вказівник на Matrix
    m->printFactorials();
}

// ============================================================
//  main
// ============================================================
int main() {
    std::cout << "=== Параметричний поліморфізм ===\n\n";

    // ── 1. Демонстрація базового класу Chislo ──────────────────
    std::cout << "--- Базовий клас Chislo ---\n";
    Chislo ch(5);
    std::cout << "factorial(5) = " << ch.factorial(5) << "\n";
    std::cout << "factorial(0) = " << ch.factorial(0) << "\n\n";

    // ── 2. Введення розмірності масиву ────────────────────────
    std::cout << "--- Клас Matrix ---\n";
    long size = 0;
    std::cout << "Введіть розмірність масиву (1–100): ";
    std::cin >> size;

    if (size < 1 || size > 100) {
        std::cerr << "Некоректна розмірність!\n";
        return 1;
    }

    // ── 3. Створення об'єкта Matrix через вказівник на Chislo ─
    Chislo* ptr = new Matrix(size);   // вказівник на базовий клас

    // ── 4. Заповнення масиву з клавіатури ─────────────────────
    Matrix* mptr = dynamic_cast<Matrix*>(ptr);
    if (mptr) mptr->fillFromKeyboard();

    // ── 5. Виклик factorial() через вказівник на базовий клас ─
    //  Оскільки Matrix НЕ перевизначає factorial(),
    //  викликається Chislo::factorial() — аналіз поліморфізму.
    std::cout << "\n--- Виклик factorial() через Chislo* ---\n";
    std::cout << "ptr->factorial(5) = " << ptr->factorial(5) << "\n";
    std::cout << "(Використовується Chislo::factorial, бо Matrix не перевизначає)\n";

    // ── 6. Обчислення факторіалів елементів масиву ────────────
    std::cout << "\n--- Факторіали через допоміжну функцію ---\n";
    processFactorials(ptr);

    // ── 7. Звільнення пам'яті ─────────────────────────────────
    std::cout << "\n--- Звільнення пам'яті ---\n";
    delete ptr;   // викличе ~Matrix(), потім ~Chislo()

    return 0;
}
