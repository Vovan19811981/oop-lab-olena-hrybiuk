#pragma once
// sparse_array.h
// Шаблонний клас розрідженого одновимірного масиву
// Лабораторна робота №6 — Шаблони (родові класи)
//
// Структура:
//   SparseElement<T>  — один елемент фізичного масиву (індекс + значення)
//   SparseArray<T>    — розріджений масив на основі std::list

#include <iostream>
#include <list>
using namespace std;

// ─────────────────────────────────────────────────────────────
// Клас одного елемента розрідженого масиву
// Зберігає: логічний індекс та значення типу T
// ─────────────────────────────────────────────────────────────
template <class T>
class SparseElement {
public:
    int index;   // логічний індекс елемента
    T   value;   // значення елемента

    // Конструктор за замовчуванням
    SparseElement() : index(0), value(T()) {}

    // Конструктор з параметрами
    SparseElement(int idx, const T& val) : index(idx), value(val) {}
};

// ─────────────────────────────────────────────────────────────
// Шаблонний клас розрідженого одновимірного масиву
// Зберігає лише ненульові (явно встановлені) елементи
// ─────────────────────────────────────────────────────────────
template <class T>
class SparseArray {
private:
    int logicalSize;                    // розмір логічного масиву
    list<SparseElement<T>> elements;    // фізичний масив (двозв'язний список)

    // Пошук елемента за логічним індексом
    // Повертає ітератор або elements.end() якщо не знайдено
    typename list<SparseElement<T>>::iterator findByIndex(int idx);

public:
    // ── Конструктори / деструктор ────────────────────────────

    // Конструктор за замовчуванням (логічний розмір = 0)
    SparseArray();

    // Конструктор з розміром логічного масиву
    explicit SparseArray(int size);

    // Конструктор копіювання
    SparseArray(const SparseArray<T>& other);

    // Деструктор
    ~SparseArray();

    // ── Оператори ────────────────────────────────────────────

    // Операція присвоєння
    SparseArray<T>& operator=(const SparseArray<T>& other);

    // Операція індексування:
    //   - якщо елемент з індексом idx існує — повертає посилання на його значення
    //   - якщо не існує — створює новий елемент і повертає посилання
    T& operator[](int idx);

    // ── Методи ───────────────────────────────────────────────

    // Виведення всіх збережених елементів на екран
    void show() const;

    // Кількість фізично збережених елементів
    int count() const;

    // Логічний розмір масиву
    int size() const;

    // Перевірка чи існує елемент з даним індексом
    bool exists(int idx) const;
};

// ─────────────────────────────────────────────────────────────
// Реалізація методів SparseArray<T>
// ─────────────────────────────────────────────────────────────

template <class T>
typename list<SparseElement<T>>::iterator
SparseArray<T>::findByIndex(int idx) {
    for (auto it = elements.begin(); it != elements.end(); ++it)
        if (it->index == idx)
            return it;
    return elements.end();
}

template <class T>
SparseArray<T>::SparseArray() : logicalSize(0) {}

template <class T>
SparseArray<T>::SparseArray(int size) : logicalSize(size) {}

template <class T>
SparseArray<T>::SparseArray(const SparseArray<T>& other)
    : logicalSize(other.logicalSize), elements(other.elements) {}

template <class T>
SparseArray<T>::~SparseArray() {
    elements.clear();
}

template <class T>
SparseArray<T>& SparseArray<T>::operator=(const SparseArray<T>& other) {
    if (this != &other) {
        logicalSize = other.logicalSize;
        elements    = other.elements;
    }
    return *this;
}

template <class T>
T& SparseArray<T>::operator[](int idx) {
    // Перевірка діапазону (якщо логічний розмір заданий)
    if (logicalSize > 0 && (idx < 0 || idx >= logicalSize)) {
        throw out_of_range(
            "Індекс " + to_string(idx) +
            " виходить за межі масиву [0, " +
            to_string(logicalSize - 1) + "]"
        );
    }

    auto it = findByIndex(idx);

    if (it != elements.end()) {
        // Елемент знайдено — повертаємо посилання
        return it->value;
    } else {
        // Елемента немає — створюємо новий з нульовим значенням
        elements.push_back(SparseElement<T>(idx, T()));
        return elements.back().value;
    }
}

template <class T>
void SparseArray<T>::show() const {
    if (elements.empty()) {
        cout << "  [ масив порожній ]\n";
        return;
    }
    cout << "  Логічний розмір: " << logicalSize
         << ", збережено елементів: " << elements.size() << "\n";

    // Виводимо у порядку зростання індексів (копіюємо і сортуємо)
    list<SparseElement<T>> sorted = elements;
    sorted.sort([](const SparseElement<T>& a, const SparseElement<T>& b) {
        return a.index < b.index;
    });

    for (const auto& el : sorted)
        cout << "  [" << el.index << "] = " << el.value << "\n";
}

template <class T>
int SparseArray<T>::count() const {
    return static_cast<int>(elements.size());
}

template <class T>
int SparseArray<T>::size() const {
    return logicalSize;
}

template <class T>
bool SparseArray<T>::exists(int idx) const {
    for (const auto& el : elements)
        if (el.index == idx)
            return true;
    return false;
}
