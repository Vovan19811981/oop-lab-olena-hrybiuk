// main.cpp
// Демонстрація шаблонного класу SparseArray<T>
// Лабораторна робота — Родові класи (шаблони)

#include <iostream>
#include <string>
#include <stdexcept>
#include "sparse_array.h"
using namespace std;

// ─── Тест 1: SparseArray<int> ─────────────────────────────────
void testInt() {
    cout << "\n========== SparseArray<int> (розмір 10) ==========\n";

    SparseArray<int> arr(10);

    // Встановлення кількох елементів (решта — "нулі", не зберігаються)
    arr[0] = 5;
    arr[3] = 42;
    arr[7] = -8;
    arr[9] = 100;

    cout << "Після присвоєння arr[0]=5, arr[3]=42, arr[7]=-8, arr[9]=100:\n";
    arr.show();

    // Доступ до існуючого елемента
    cout << "\nЧитання arr[3] = " << arr[3] << "\n";

    // Доступ до неіснуючого — автоматично створює
    cout << "Доступ до arr[5] (не існував): " << arr[5] << "\n";
    cout << "Тепер arr[5] збережений у фізичному масиві:\n";
    arr.show();

    // Перевірка існування
    cout << "\nЧи існує arr[7]? " << (arr.exists(7) ? "так" : "ні") << "\n";
    cout << "Чи існує arr[2]? " << (arr.exists(2) ? "так" : "ні") << "\n";

    // Вихід за межі
    try {
        arr[15] = 99;
    } catch (const out_of_range& e) {
        cout << "\nВиключення: " << e.what() << "\n";
    }
}

// ─── Тест 2: SparseArray<double> ──────────────────────────────
void testDouble() {
    cout << "\n========== SparseArray<double> (розмір 20) ==========\n";

    SparseArray<double> arr(20);

    arr[1]  = 3.14;
    arr[5]  = 2.71828;
    arr[10] = 1.41421;
    arr[19] = 0.57721;

    cout << "Збережені елементи:\n";
    arr.show();

    cout << "\nКількість фізично збережених: " << arr.count() << "\n";
    cout << "Логічний розмір масиву:        " << arr.size()  << "\n";
}

// ─── Тест 3: SparseArray<string> ──────────────────────────────
void testString() {
    cout << "\n========== SparseArray<string> (розмір 50) ==========\n";

    SparseArray<string> arr(50);

    arr[0]  = "шаблон";
    arr[10] = "розріджений";
    arr[25] = "масив";
    arr[49] = "C++";

    cout << "Збережені елементи:\n";
    arr.show();
}

// ─── Тест 4: Конструктор копіювання та operator= ──────────────
void testCopyAndAssign() {
    cout << "\n========== Копіювання та присвоєння ==========\n";

    SparseArray<int> original(10);
    original[1] = 11;
    original[4] = 44;
    original[8] = 88;

    // Конструктор копіювання
    SparseArray<int> copy(original);
    cout << "Оригінал:\n";
    original.show();
    cout << "Копія (конструктор копіювання):\n";
    copy.show();

    // Зміна копії не впливає на оригінал
    copy[1] = 999;
    cout << "Після copy[1]=999:\n";
    cout << "  Оригінал arr[1] = " << original[1] << "\n";
    cout << "  Копія    arr[1] = " << copy[1]     << "\n";

    // Оператор присвоєння
    SparseArray<int> assigned(5);
    assigned = original;
    cout << "Присвоєний (operator=):\n";
    assigned.show();
}

// ─── Тест 5: Конструктор за замовчуванням ─────────────────────
void testDefault() {
    cout << "\n========== Конструктор за замовчуванням ==========\n";

    SparseArray<float> arr; // без розміру — без перевірки меж
    arr[100] = 1.1f;
    arr[500] = 5.5f;
    arr[999] = 9.9f;

    cout << "Масив без обмеження розміру:\n";
    arr.show();
}

// ─── Точка входу ──────────────────────────────────────────────
int main() {
    testInt();
    testDouble();
    testString();
    testCopyAndAssign();
    testDefault();

    cout << "\n=== Завершено ===\n";
    return 0;
}
