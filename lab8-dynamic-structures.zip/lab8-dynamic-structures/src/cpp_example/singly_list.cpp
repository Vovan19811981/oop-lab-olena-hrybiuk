/*
 * Практична робота №8 — Динамічні структури даних
 * C++ приклад: Однозв'язний список із класами функцій
 *
 * Компіляція: g++ -std=c++17 singly_list.cpp -o singly_list
 */

#include <iostream>
using namespace std;

/* ─── Структури даних ─── */
struct Data {
    int  x;
    char ch;
};

struct TList {
    Data   info;
    TList* next;
};

/* ─── Глобальні покажчики ─── */
TList* head = nullptr;
TList* tail = nullptr;

/* ═══════════════════════════════════════════
 *  Create — Додавання вузла в кінець списку
 * ═══════════════════════════════════════════ */
void Create(Data tt) {
    TList* temp  = new TList;
    temp->next   = nullptr;
    temp->info.x  = tt.x;
    temp->info.ch = tt.ch;

    if (head == nullptr) {
        /* Перший елемент — голова і хвіст */
        head = tail = temp;
    } else {
        /* Підвішуємо до хвоста */
        tail->next = temp;
        tail       = temp;
    }
}

/* ═══════════════════════════════════════════
 *  Show — Виведення всього списку
 * ═══════════════════════════════════════════ */
void Show() {
    TList* temp = head;
    int i = 1;

    if (temp == nullptr) {
        cout << "Список порожній.\n";
        return;
    }

    while (temp != nullptr) {
        cout << "[" << i++ << "] x=" << temp->info.x
             << "  ch=" << temp->info.ch << "\n";
        temp = temp->next;
    }
}

/* ═══════════════════════════════════════════
 *  ADD — Вставка вузла на позицію el (0-based)
 * ═══════════════════════════════════════════ */
void ADD(int el, Data tt) {
    TList* temp = new TList;
    temp->info.x  = tt.x;
    temp->info.ch = tt.ch;

    if (el == 0) {
        /* Вставка на початок */
        temp->next = head;
        head       = temp;
    } else {
        /* Знаходимо вузол перед позицією el */
        TList* temp_pos = head;
        for (int i = 0; i < el - 1; i++)
            temp_pos = temp_pos->next;

        temp->next      = temp_pos->next;
        temp_pos->next  = temp;

        /* Якщо вставили в кінець — оновлюємо tail */
        if (temp->next == nullptr)
            tail = temp;
    }
}

/* ═══════════════════════════════════════════
 *  Erase — Видалення вузла на позиції el (0-based)
 * ═══════════════════════════════════════════ */
void Erase(int el) {
    if (head == nullptr) {
        cout << "Список порожній!\n";
        return;
    }

    TList* temp_pos = head;

    if (el == 0) {
        /* Видалення першого елементу */
        head = head->next;
        if (head == nullptr) tail = nullptr;
        delete temp_pos;
    } else {
        for (int i = 0; i < el - 1; i++) {
            if (temp_pos->next == nullptr) {
                cout << "Позиція за межами списку!\n";
                return;
            }
            temp_pos = temp_pos->next;
        }

        TList* temp = temp_pos->next;
        if (temp == nullptr) {
            cout << "Позиція за межами списку!\n";
            return;
        }

        if (temp->next == nullptr)
            tail = temp_pos;          /* Видаляємо хвіст */

        temp_pos->next = temp->next;
        delete temp;
    }
}

/* ═══════════════════════════════════════════
 *  FreeList — Звільнення всієї пам'яті
 * ═══════════════════════════════════════════ */
void FreeList() {
    TList* curr = head;
    while (curr != nullptr) {
        TList* tmp = curr->next;
        delete curr;
        curr = tmp;
    }
    head = tail = nullptr;
}

/* ═══════════════════════════════════════════
 *  MAIN
 * ═══════════════════════════════════════════ */
int main() {
    cout << "=== C++ Однозв'язний список ===\n\n";

    /* Заповнення списку */
    Data d;
    for (int i = 1; i <= 5; i++) {
        d.x  = i * 10;
        d.ch = 'A' + i - 1;
        Create(d);
    }

    cout << "Початковий список:\n";
    Show();

    /* Вставка на початок */
    cout << "\nВставка {99, 'Z'} на позицію 0:\n";
    d = {99, 'Z'};
    ADD(0, d);
    Show();

    /* Вставка в середину */
    cout << "\nВставка {55, 'M'} на позицію 3:\n";
    d = {55, 'M'};
    ADD(3, d);
    Show();

    /* Видалення першого */
    cout << "\nВидалення елементу на позиції 0:\n";
    Erase(0);
    Show();

    /* Видалення з середини */
    cout << "\nВидалення елементу на позиції 2:\n";
    Erase(2);
    Show();

    FreeList();
    cout << "\nПам'ять звільнено.\n";
    return 0;
}
