/*
 * Практична робота №8 — Динамічні структури даних
 * C++ приклад: Двозв'язний список
 *
 * Компіляція: g++ -std=c++17 doubly_list.cpp -o doubly_list
 */

#include <iostream>
using namespace std;

/* ─── Структури даних ─── */
struct Data {
    int  x;
    char ch;
};

struct TList {
    Data   info;
    TList* next;   /* покажчик на НАСТУПНИЙ  елемент */
    TList* prev;   /* покажчик на ПОПЕРЕДНІЙ елемент */
};

/* ─── Глобальні покажчики ─── */
TList* head = nullptr;
TList* tail = nullptr;

/* ═══════════════════════════════════════════
 *  Create2 — Додавання вузла в кінець списку
 * ═══════════════════════════════════════════ */
void Create2(Data tt) {
    TList* temp   = new TList;
    temp->info.x  = tt.x;
    temp->info.ch = tt.ch;
    temp->next    = nullptr;

    if (head == nullptr) {
        /* Перший елемент */
        temp->prev = nullptr;
        head = tail = temp;
    } else {
        /* Додаємо після хвоста */
        tail->next = temp;
        temp->prev = tail;
        tail       = temp;
    }
}

/* ═══════════════════════════════════════════
 *  Show2_r — Виведення від початку до кінця
 * ═══════════════════════════════════════════ */
void Show2_r() {
    TList* temp = head;
    int i = 1;

    if (!temp) { cout << "Список порожній.\n"; return; }

    cout << "→ Від початку:\n";
    while (temp != nullptr) {
        cout << "  [" << i++ << "] x=" << temp->info.x
             << "  ch=" << temp->info.ch << "\n";
        temp = temp->next;
    }
}

/* ═══════════════════════════════════════════
 *  Show2_l — Виведення від кінця до початку
 * ═══════════════════════════════════════════ */
void Show2_l() {
    TList* temp = tail;
    int i = 1;

    if (!temp) { cout << "Список порожній.\n"; return; }

    cout << "← Від кінця:\n";
    while (temp != nullptr) {
        cout << "  [" << i++ << "] x=" << temp->info.x
             << "  ch=" << temp->info.ch << "\n";
        temp = temp->prev;
    }
}

/* ═══════════════════════════════════════════
 *  ADD2 — Вставка на позицію el (0-based)
 * ═══════════════════════════════════════════ */
void ADD2(int el, Data tt) {
    TList* temp   = new TList;
    temp->info.x  = tt.x;
    temp->info.ch = tt.ch;

    if (el == 0) {
        /* Вставка на початок */
        temp->next  = head;
        temp->prev  = nullptr;
        if (head) head->prev = temp;
        head = temp;
        if (tail == nullptr) tail = temp;

    } else {
        TList* temp_pos = head;
        for (int i = 0; i < el - 1; i++)
            temp_pos = temp_pos->next;

        if (temp_pos->next == nullptr) {
            /* Вставка в кінець */
            tail->next = temp;
            temp->prev = tail;
            temp->next = nullptr;
            tail = temp;
        } else {
            /* Вставка в середину */
            temp->next            = temp_pos->next;   /* 1 next */
            temp_pos->next        = temp;              /* 2 next */
            temp->next->prev      = temp;              /* 3 prev */
            temp->prev            = temp_pos;          /* 4 prev */
        }
    }
}

/* ═══════════════════════════════════════════
 *  Erase2 — Видалення вузла на позиції el (0-based)
 * ═══════════════════════════════════════════ */
void Erase2(int el) {
    if (head == nullptr) {
        cout << "Список порожній!\n";
        return;
    }

    TList* temp_pos = head;

    if (el == 0) {
        /* Видалення першого */
        head = head->next;
        if (head) head->prev = nullptr;
        else      tail = nullptr;
        delete temp_pos;
    } else {
        for (int i = 0; i < el - 1; i++) {
            if (!temp_pos->next) { cout << "Позиція за межами!\n"; return; }
            temp_pos = temp_pos->next;
        }

        TList* temp = temp_pos->next;
        if (!temp) { cout << "Позиція за межами!\n"; return; }

        if (temp->next == nullptr) {
            /* Видалення останнього */
            temp_pos->next = nullptr;
            tail = temp_pos;
        } else {
            /* Видалення з середини */
            temp_pos->next       = temp->next;
            temp->next->prev     = temp_pos;
        }
        delete temp;
    }
}

/* ═══════════════════════════════════════════
 *  FreeList — Звільнення всієї пам'яті
 * ═══════════════════════════════════════════ */
void FreeList() {
    TList* curr = head;
    while (curr) {
        TList* tmp = curr->next;
        delete curr;
        curr = tmp;
    }
    head = tail = nullptr;
}

/* ═══════════════════════════════════════════
 *  MAIN
 * ═══════════════════════════════════════════ */
int main() {
    cout << "=== C++ Двозв'язний список ===\n\n";

    /* Заповнення */
    Data d;
    for (int i = 1; i <= 5; i++) {
        d = { i * 10, (char)('A' + i - 1) };
        Create2(d);
    }

    cout << "Початковий список:\n";
    Show2_r();
    cout << "\n";
    Show2_l();

    /* Вставка на початок */
    cout << "\nВставка {99, 'Z'} на позицію 0:\n";
    d = {99, 'Z'};
    ADD2(0, d);
    Show2_r();

    /* Вставка в середину */
    cout << "\nВставка {55, 'M'} на позицію 3:\n";
    d = {55, 'M'};
    ADD2(3, d);
    Show2_r();

    /* Вставка в кінець */
    cout << "\nВставка {1, 'a'} в кінець (позиція 7):\n";
    d = {1, 'a'};
    ADD2(7, d);
    Show2_r();

    /* Видалення першого */
    cout << "\nВидалення позиції 0:\n";
    Erase2(0);
    Show2_r();

    /* Видалення з середини */
    cout << "\nВидалення позиції 2:\n";
    Erase2(2);
    Show2_r();

    /* Перегляд зворотній */
    cout << "\nФінальний список у зворотному порядку:\n";
    Show2_l();

    FreeList();
    cout << "\nПам'ять звільнено.\n";
    return 0;
}
