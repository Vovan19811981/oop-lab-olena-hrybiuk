/*
 * Практична робота №8 — Динамічні структури даних
 * Задача 3: Двозв'язний список
 *   - перегляд з початку
 *   - перегляд з кінця
 *   - видалення вузла з заданими даними
 *   - видалення списку
 *
 * Компіляція (Windows): gcc task3_doubly_list.c -o task3.exe
 * Компіляція (Linux):   gcc task3_doubly_list.c -o task3
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
  #include <conio.h>
  #include <Windows.h>
  #define CLEAR "cls"
  #define GETCH() _getch()
#else
  #include <termios.h>
  #define CLEAR "clear"
  int GETCH(void) {
      struct termios oldt, newt;
      int ch;
      tcgetattr(0, &oldt);
      newt = oldt;
      newt.c_lflag &= ~(ICANON | ECHO);
      tcsetattr(0, TCSANOW, &newt);
      ch = getchar();
      tcsetattr(0, TCSANOW, &oldt);
      return ch;
  }
#endif

/* ─── Структура вузла двозв'язного списку ─── */
struct spis {
    char data[20];
    struct spis* v1;   /* покажчик на ПОПЕРЕДНІЙ вузол */
    struct spis* v2;   /* покажчик на НАСТУПНИЙ  вузол */
};

/* Глобальні покажчики на початок і кінець списку */
struct spis* head;
struct spis* tail;

/* ─── Прототипи функцій ─── */
void create(void);
void list_forward(void);
void list_backward(void);
void del(void);
void free_list(void);

/* ═══════════════════════════════
 *  ГОЛОВНА ФУНКЦІЯ
 * ═══════════════════════════════ */
int main(void) {
#ifdef _WIN32
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
#endif
    system(CLEAR);

    printf("=== Двозв'язний список ===\n\n");

    /* 1. Створення */
    create();

    /* 2. Перегляд з початку */
    printf("\n--- Список з початку ---\n");
    list_forward();

    /* 3. Перегляд з кінця */
    printf("\n--- Список з кінця ---\n");
    list_backward();

    /* 4. Видалення вузла */
    del();

    /* 5. Перегляд після видалення */
    printf("\n--- Список після видалення (з початку) ---\n");
    list_forward();

    /* 6. Звільнення пам'яті */
    free_list();
    printf("\nСписок видалено з пам'яті.\n");

    return 0;
}

/* ═══════════════════════════════
 *  Створення двозв'язного списку
 * ═══════════════════════════════ */
void create(void) {
    struct spis* p;
    struct spis* pred = NULL;

    printf("Введіть прізвища (Enter після кожного, Esc для завершення):\n");

    do {
        p = (struct spis*)malloc(sizeof(struct spis));
        if (!p) { fprintf(stderr, "Помилка пам'яті\n"); exit(1); }

        printf("Прізвище: ");
#ifdef _WIN32
        gets_s(p->data, sizeof(p->data));
#else
        fgets(p->data, sizeof(p->data), stdin);
        /* Видалити символ нового рядка */
        p->data[strcspn(p->data, "\n")] = '\0';
#endif

        p->v1 = pred;              /* посилання на попередній */
        if (pred != NULL)
            pred->v2 = p;          /* попередній вказує на поточний */
        else
            head = p;              /* перший елемент — голова */

        pred = p;

        printf("Закінчити? (Esc = так, будь-яка інша = ні): ");

    } while (GETCH() != 27);      /* 27 = Esc */

    printf("\n");
    tail = p;
    tail->v2 = NULL;              /* хвіст вказує на NULL */
}

/* ═══════════════════════════════
 *  Перегляд від початку до кінця
 * ═══════════════════════════════ */
void list_forward(void) {
    struct spis* p = head;
    int i = 1;

    if (p == NULL) { printf("Список порожній.\n"); return; }

    while (p != NULL) {
        printf("%d. %s\n", i++, p->data);
        p = p->v2;
    }
}

/* ═══════════════════════════════
 *  Перегляд від кінця до початку
 * ═══════════════════════════════ */
void list_backward(void) {
    struct spis* p = tail;
    int i = 1;

    if (p == NULL) { printf("Список порожній.\n"); return; }

    while (p != NULL) {
        printf("%d. %s\n", i++, p->data);
        p = p->v1;
    }
}

/* ═══════════════════════════════
 *  Видалення вузла за прізвищем
 * ═══════════════════════════════ */
void del(void) {
    struct spis* p;
    struct spis* temp;
    char f[20];
    int found = 0;

    system(CLEAR);
    printf("Введіть прізвище для видалення: ");
#ifdef _WIN32
    gets_s(f, sizeof(f));
#else
    fgets(f, sizeof(f), stdin);
    f[strcspn(f, "\n")] = '\0';
#endif

    p = head;

    while (p != NULL) {
        if (strcmp(p->data, f) == 0) {
            found = 1;

            if (p == head && p == tail) {
                /* Єдиний елемент у списку */
                head = tail = NULL;
                free(p);
                p = NULL;

            } else if (p == head) {
                /* Видалення першого елементу */
                head    = p->v2;
                head->v1 = NULL;
                free(p);
                p = head;

            } else if (p == tail) {
                /* Видалення останнього елементу */
                tail    = p->v1;
                tail->v2 = NULL;
                free(p);
                p = NULL;   /* Кінець списку */

            } else {
                /* Видалення з середини */
                p->v2->v1 = p->v1;
                p->v1->v2 = p->v2;
                temp = p;
                p    = p->v2;
                free(temp);
            }
        } else {
            p = p->v2;
        }
    }

    if (found) printf("\nПрізвище \"%s\" видалено зі списку.\n", f);
    else       printf("\nПрізвище \"%s\" не знайдено.\n", f);
}

/* ═══════════════════════════════
 *  Звільнення всього списку
 * ═══════════════════════════════ */
void free_list(void) {
    struct spis* p = head;
    struct spis* tmp;

    while (p != NULL) {
        tmp = p->v2;
        free(p);
        p = tmp;
    }

    head = tail = NULL;
}
