/*
 * Практична робота №8 — Динамічні структури даних
 * Задача 1: Однозв'язний список — створення та перегляд
 *
 * Компіляція (Windows): gcc task1_singly_list.c -o task1.exe
 * Компіляція (Linux):   gcc task1_singly_list.c -o task1
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
  #include <conio.h>
  #include <Windows.h>
  #define CLEAR "cls"
  #define GETCH() _getch()
#else
  #include <termios.h>
  #define CLEAR "clear"
  /* Замінник _getch() для Linux/macOS */
  int GETCH(void) {
      struct termios oldt, newt;
      int ch;
      tcgetattr(0, &oldt);
      newt = oldt;
      newt.c_lflag &= ~(ICANON | ECHO);
      tcsetattr(0, TCSANOW, &newt);
      ch = getchar();
      tcsetattr(0, TCSANOW, &oldt);
      return ch;
  }
#endif

/* ─── Структура вузла списку ─── */
struct spis {
    char data[20];
    struct spis* next;
};

/* Глобальний покажчик на голову списку */
struct spis* head;

/* ─── Прототипи функцій ─── */
struct spis* create(void);
void         list(struct spis* head);

/* ═══════════════════════════════
 *  ГОЛОВНА ФУНКЦІЯ
 * ═══════════════════════════════ */
int main(void) {
#ifdef _WIN32
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
#endif
    system(CLEAR);

    printf("=== Однозв'язний список: створення та перегляд ===\n\n");

    head = create();

    printf("\n--- Вміст списку ---\n");
    list(head);

    /* Звільнення пам'яті */
    struct spis* curr = head;
    while (curr != NULL) {
        struct spis* tmp = curr->next;
        free(curr);
        curr = tmp;
    }

    return 0;
}

/* ═══════════════════════════════
 *  Функція створення списку
 *  Повертає адресу голови списку
 * ═══════════════════════════════ */
struct spis* create(void) {
    struct spis* p;
    struct spis* pred;
    char c;

    /* Виділяємо пам'ять для першого запису */
    head = pred = p = (struct spis*)malloc(sizeof(struct spis));
    if (!p) { fprintf(stderr, "Помилка виділення пам'яті\n"); exit(1); }

    printf("Прізвище: ");
    scanf("%19s", p->data);

    do {
        p = (struct spis*)malloc(sizeof(struct spis));
        if (!p) { fprintf(stderr, "Помилка виділення пам'яті\n"); exit(1); }

        printf("Прізвище: ");
        scanf("%19s", p->data);

        /* Посилання з попереднього запису на поточний */
        pred->next = p;
        /* Поточний запис стає попереднім */
        pred = p;

        printf("Закінчити? (y/n): ");
        c = (char)GETCH();
        printf("\n");

    } while (c != 'y' && c != 'Y');

    p->next = NULL;   /* Останній елемент вказує на NULL */
    return head;
}

/* ═══════════════════════════════
 *  Функція перегляду списку
 * ═══════════════════════════════ */
void list(struct spis* head) {
    struct spis* p = head;
    int i = 1;

    if (p == NULL) {
        printf("Список порожній.\n");
        return;
    }

    while (p != NULL) {
        printf("%d. %s\n", i++, p->data);
        p = p->next;   /* Просування по списку */
    }
}
