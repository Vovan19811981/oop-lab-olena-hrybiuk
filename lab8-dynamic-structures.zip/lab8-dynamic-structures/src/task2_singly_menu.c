/*
 * Практична робота №8 — Динамічні структури даних
 * Задача 2: Однозв'язний список з повним меню операцій
 *
 * Компіляція (Windows): gcc task2_singly_menu.c -o task2.exe
 * Компіляція (Linux):   gcc task2_singly_menu.c -o task2
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
  #include <conio.h>
  #include <Windows.h>
  #define CLEAR "cls"
  #define GETCH() _getch()
#else
  #include <termios.h>
  #define CLEAR "clear"
  int GETCH(void) {
      struct termios oldt, newt;
      int ch;
      tcgetattr(0, &oldt);
      newt = oldt;
      newt.c_lflag &= ~(ICANON | ECHO);
      tcsetattr(0, TCSANOW, &newt);
      ch = getchar();
      tcsetattr(0, TCSANOW, &oldt);
      return ch;
  }
#endif

#define TRUE 1

/* ─── Структура вузла списку ─── */
struct List {
    int x;
    struct List* Next;
};

/* ─── Прототипи функцій ─── */
struct List* CreateList(void);
void         DisplayList(struct List* Begin);
void         RemoveTermBegin(struct List** Begin);
void         RemoveTermTag(struct List* Begin);
void         RemoveTermEnd(struct List* Begin);
void         AddTermBegin(struct List** Begin);
void         AddTermEnd(struct List* Begin);
void         AddTermTag(struct List* Begin);
void         FreeList(struct List** Begin);
void         PrintMenu(void);

/* ═══════════════════════════════
 *  ГОЛОВНА ФУНКЦІЯ
 * ═══════════════════════════════ */
int main(void) {
#ifdef _WIN32
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
#endif

    struct List* Begin = NULL;
    char Key;

    while (TRUE) {
        PrintMenu();

        /* Очистка буфера вводу */
        scanf("%*[^\n]");
        scanf("%*c");
        scanf("%c", &Key);
        system(CLEAR);

        switch (Key) {
            case '1':
                system(CLEAR);
                Begin = CreateList();
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '2':
                system(CLEAR);
                DisplayList(Begin);
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '3':
                system(CLEAR);
                if (Begin == NULL) { printf("Список порожній!\n"); }
                else               { RemoveTermBegin(&Begin); printf("Елемент видалено з початку.\n"); }
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '4':
                system(CLEAR);
                if (Begin == NULL) { printf("Список порожній!\n"); }
                else               { RemoveTermTag(Begin); }
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '5':
                system(CLEAR);
                if (Begin == NULL) { printf("Список порожній!\n"); }
                else               { RemoveTermEnd(Begin); printf("Елемент видалено з кінця.\n"); }
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '6':
                system(CLEAR);
                AddTermBegin(&Begin);
                printf("Елемент додано на початок.\n");
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '7':
                system(CLEAR);
                if (Begin == NULL) { printf("Список порожній! Спочатку створіть список (пункт 1).\n"); }
                else               { AddTermEnd(Begin); printf("Елемент додано в кінець.\n"); }
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '8':
                system(CLEAR);
                if (Begin == NULL) { printf("Список порожній!\n"); }
                else               { AddTermTag(Begin); }
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;

            case '9':
                FreeList(&Begin);
                printf("Список очищено. До побачення!\n");
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                return 0;

            default:
                system(CLEAR);
                printf("\nНеправильний вибір! Спробуйте ще раз.\n");
                printf("\n\nНатисніть будь-яку клавішу...\n");
                GETCH();
                system(CLEAR);
                break;
        }
    }
}

/* ─── Виведення меню ─── */
void PrintMenu(void) {
    printf("╔══════════════════════════════════════════════╗\n");
    printf("║      ОДНОЗВ'ЯЗНИЙ СПИСОК — МЕНЮ ОПЕРАЦІЙ    ║\n");
    printf("╠══════════════════════════════════════════════╣\n");
    printf("║  1 — Створення списку                        ║\n");
    printf("║  2 — Перегляд списку                         ║\n");
    printf("║  3 — Видалення елементу з початку            ║\n");
    printf("║  4 — Видалення елементу за ключем            ║\n");
    printf("║  5 — Видалення елементу з кінця              ║\n");
    printf("║  6 — Додавання елементу на початок           ║\n");
    printf("║  7 — Додавання елементу в кінець             ║\n");
    printf("║  8 — Додавання елементу за ключем            ║\n");
    printf("║  9 — Вихід та очищення списку                ║\n");
    printf("╚══════════════════════════════════════════════╝\n");
    printf("Ваш вибір: ");
}

/* ═══════════════════════════════
 *  Створення списку
 * ═══════════════════════════════ */
struct List* CreateList(void) {
    struct List* Begin   = NULL;
    struct List* Previos = NULL;
    struct List* Current = NULL;
    char Ok = 'y';

    while (Ok == 'y' || Ok == 'Y') {
        printf("Введіть число: ");
        Current = (struct List*)malloc(sizeof(struct List));
        if (!Current) { fprintf(stderr, "Помилка пам'яті\n"); exit(1); }

        if (Begin == NULL)
            Begin = Current;
        else
            Previos->Next = Current;

        Previos = Current;
        scanf("%d", &Current->x);

        /* Очистка буфера */
        scanf("%*[^\n]");
        scanf("%*c");

        printf("Продовжити? (y/n): ");
        scanf("%c", &Ok);
    }

    if (Previos) Previos->Next = NULL;
    return Begin;
}

/* ═══════════════════════════════
 *  Перегляд списку
 * ═══════════════════════════════ */
void DisplayList(struct List* Begin) {
    struct List* Current = Begin;
    int i = 1;

    if (Begin == NULL) {
        printf("Список порожній.\n");
        return;
    }

    printf("\nСписок чисел:\n");
    while (Current) {
        printf("[%d] %d\n", i++, Current->x);
        Current = Current->Next;
    }
    printf("\n");
}

/* ═══════════════════════════════
 *  Видалення першого елементу
 * ═══════════════════════════════ */
void RemoveTermBegin(struct List** Begin) {
    struct List* Current = *Begin;
    *Begin = Current->Next;
    free(Current);
}

/* ═══════════════════════════════
 *  Видалення за ключем (значенням)
 * ═══════════════════════════════ */
void RemoveTermTag(struct List* Begin) {
    struct List* Current = Begin;
    struct List* Previos = Current;
    int NumberTag;
    int found = 0;

    printf("Введіть ключ для видалення: ");
    scanf("%d", &NumberTag);

    while (Current) {
        if (Current->x == NumberTag) {
            found = 1;
            Previos->Next = Current->Next;
            free(Current);
            Current = Previos->Next;
        } else {
            Previos = Current;
            Current = Current->Next;
        }
    }

    if (found) printf("Елемент(и) з ключем %d видалено.\n", NumberTag);
    else       printf("Елемент з ключем %d не знайдено.\n", NumberTag);
}

/* ═══════════════════════════════
 *  Видалення останнього елементу
 * ═══════════════════════════════ */
void RemoveTermEnd(struct List* Begin) {
    struct List* Current = Begin;
    struct List* Previos = NULL;

    while (Current->Next) {
        Previos = Current;
        Current = Current->Next;
    }

    if (Previos) Previos->Next = NULL;
    free(Current);
}

/* ═══════════════════════════════
 *  Додавання на початок
 * ═══════════════════════════════ */
void AddTermBegin(struct List** Begin) {
    struct List* Current = (struct List*)malloc(sizeof(struct List));
    if (!Current) { fprintf(stderr, "Помилка пам'яті\n"); exit(1); }

    printf("Введіть число: ");
    scanf("%d", &Current->x);

    Current->Next = *Begin;
    *Begin = Current;
}

/* ═══════════════════════════════
 *  Додавання в кінець
 * ═══════════════════════════════ */
void AddTermEnd(struct List* Begin) {
    struct List* Current = Begin;
    struct List* Previos = NULL;

    while (Current) {
        Previos = Current;
        Current = Current->Next;
    }

    Current = (struct List*)malloc(sizeof(struct List));
    if (!Current) { fprintf(stderr, "Помилка пам'яті\n"); exit(1); }

    Previos->Next = Current;
    printf("Введіть число: ");
    scanf("%d", &Current->x);
    Current->Next = NULL;
}

/* ═══════════════════════════════
 *  Додавання після елементу за ключем
 * ═══════════════════════════════ */
void AddTermTag(struct List* Begin) {
    struct List* Current = Begin;
    struct List* Previos = Current;
    int NumberTag;

    printf("Введіть ключ (після якого додати): ");
    scanf("%d", &NumberTag);

    while (Current) {
        if (Current->x == NumberTag) {
            Previos = Current;
            Current = (struct List*)malloc(sizeof(struct List));
            if (!Current) { fprintf(stderr, "Помилка пам'яті\n"); exit(1); }

            Current->Next  = Previos->Next;
            Previos->Next  = Current;

            printf("Введіть число: ");
            scanf("%d", &Current->x);
            printf("Елемент додано після %d.\n", NumberTag);
            break;
        } else {
            Previos = Current;
            Current = Current->Next;
        }
    }

    if (!Current) printf("Ключ %d не знайдено.\n", NumberTag);
}

/* ═══════════════════════════════
 *  Очищення всього списку
 * ═══════════════════════════════ */
void FreeList(struct List** Begin) {
    struct List* Current = *Begin;
    while (Current) {
        *Begin = (*Begin)->Next;
        free(Current);
        Current = *Begin;
    }
}
