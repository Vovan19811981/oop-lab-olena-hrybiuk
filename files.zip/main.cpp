#include <iostream>
#include <stdexcept>
#include <string>

// ============================================================
//  Власний клас виняткових ситуацій для Vect
// ============================================================
class VectException : public std::exception {
private:
    std::string message;
public:
    explicit VectException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override { return message.c_str(); }
};

// ============================================================
//  Клас Vect — виправлена версія з обробкою виняткових ситуацій
//
//  ПОМИЛКА оригінального коду:
//    char size — тип signed char, діапазон -128..+127
//    При передачі 200: 200 = 0xC8 = 11001000 → старший біт=1
//    Комп'ютер інтерпретує як від'ємне: -56 (доповняльний код)
//    new int[-56] → new повертає 0 → помилка
//
//  ВИПРАВЛЕННЯ (без зміни типу поля):
//    Перед виділенням пам'яті привести size до unsigned char
//    та перевірити реальний розмір > 0
// ============================================================
class Vect {
public:
    // Конструктор з перехопленням виняткових ситуацій
    explicit Vect(char n);

    // Деструктор з безпечним очищенням (через метод Destroy)
    ~Vect();

    // Перевантаження [] з перевіркою меж масиву
    int& operator[](int i);

    // Вивід елементів масиву
    void Print() const;

private:
    char  size;     // розмір масиву (signed char, як в оригіналі)
    int*  p;        // вказівник на масив (тип поля не змінюємо — char)

    // Допоміжний метод для безпечного звільнення пам'яті
    // (викликається з деструктора через try/catch)
    void Destroy();
};

// ── Конструктор ──────────────────────────────────────────────
Vect::Vect(char n) : size(n), p(nullptr) {
    // Приводимо до unsigned char, щоб отримати реальне значення
    // (виправлення помилки: char 200 → signed -56, але unsigned → 200)
    unsigned char realSize = static_cast<unsigned char>(size);

    std::cout << "[Vect] Конструктор: char=" << static_cast<int>(n)
              << ", unsigned=" << static_cast<int>(realSize) << "\n";

    if (realSize == 0) {
        throw VectException("Конструктор Vect: розмір масиву не може бути 0!");
    }

    // Виділяємо пам'ять через realSize (unsigned), а не size (signed)
    p = new (std::nothrow) int[realSize];

    if (!p) {
        throw VectException(
            std::string("Конструктор Vect: не вдалося виділити пам'ять для масиву розміром ") +
            std::to_string(static_cast<int>(realSize))
        );
    }

    // Ініціалізація нулями
    for (int i = 0; i < static_cast<int>(realSize); ++i)
        p[i] = 0;

    std::cout << "[Vect] Масив успішно створено, розмір = "
              << static_cast<int>(realSize) << "\n";
}

// ── Деструктор ───────────────────────────────────────────────
// Правило: жодне виключення не повинне залишити межі деструктора!
// Тому всі складні дії інкапсульовано у Destroy() з try/catch
Vect::~Vect() {
    std::cout << "[Vect] Деструктор викликано\n";
    try {
        Destroy();
    }
    catch (const VectException& e) {
        // Поглинаємо виняток — він не повинен виходити з деструктора
        std::cerr << "[Vect] Деструктор перехопив виняток: " << e.what() << "\n";
    }
    catch (...) {
        // Перехоплення будь-яких інших виняткових ситуацій
        std::cerr << "[Vect] Деструктор: невідома виняткова ситуація!\n";
    }
}

// ── Допоміжний метод очищення ────────────────────────────────
void Vect::Destroy() {
    if (p) {
        delete[] p;
        p = nullptr;
        std::cout << "[Vect] Пам'ять успішно звільнено\n";
    } else {
        // Демонстрація: кидаємо виняток, який буде перехоплено в ~Vect()
        throw VectException("Destroy: вказівник вже nullptr!");
    }
}

// ── Перевантаження [] ─────────────────────────────────────────
int& Vect::operator[](int i) {
    unsigned char realSize = static_cast<unsigned char>(size);
    if (i < 0 || i >= static_cast<int>(realSize)) {
        throw VectException(
            std::string("operator[]: індекс ") + std::to_string(i) +
            " виходить за межі масиву [0.." +
            std::to_string(static_cast<int>(realSize) - 1) + "]"
        );
    }
    if (!p) {
        throw VectException("operator[]: вказівник p == nullptr!");
    }
    return p[i];
}

// ── Вивід ─────────────────────────────────────────────────────
void Vect::Print() const {
    unsigned char realSize = static_cast<unsigned char>(size);
    for (int i = 0; i < static_cast<int>(realSize); ++i)
        std::cout << p[i] << " ";
    std::cout << "\n";
}

// ============================================================
//  Допоміжна функція — демонстрація з кількома catch
// ============================================================
void Xhandler(int test) {
    try {
        if (test != 0)
            throw test;
        else
            throw std::string("Значення дорівнює нулю");
    }
    catch (int i) {
        std::cout << "  [Xhandler] Перехоплена int-помилка: " << i << "\n";
    }
    catch (const std::string& s) {
        std::cout << "  [Xhandler] Перехоплений рядок: " << s << "\n";
    }
    catch (...) {
        std::cout << "  [Xhandler] Перехоплено невідомий тип виключення\n";
    }
}

// ============================================================
//  main
// ============================================================
int main() {
    std::cout << "========================================\n";
    std::cout << " ЛР 2.3: Обробка виняткових ситуацій\n";
    std::cout << "========================================\n\n";

    // ── Крок 1: Оригінальний код з виправленням ──────────────
    std::cout << "--- Крок 1: нормальна робота Vect(3) ---\n";
    try {
        Vect a(3);
        a[0] = 0;
        a[1] = 1;
        a[2] = 2;
        a.Print();
    }
    catch (const VectException& e) {
        std::cerr << "ПОМИЛКА: " << e.what() << "\n";
    }

    // ── Крок 2: Демонстрація помилки оригіналу — char 200 ───
    std::cout << "\n--- Крок 2: Vect(200) — помилка типу char ---\n";
    std::cout << "Пояснення: char(200) = signed -56 → без виправлення new(-56) = nullptr\n";
    std::cout << "Виправлено: приводимо до unsigned char → реальний розмір 200\n";
    try {
        Vect a1(static_cast<char>(200));  // char(200) = -56 signed
        a1[10] = 5;
        a1.Print();
    }
    catch (const VectException& e) {
        std::cerr << "ПЕРЕХОПЛЕНО VectException: " << e.what() << "\n";
    }
    catch (const std::exception& e) {
        std::cerr << "ПЕРЕХОПЛЕНО std::exception: " << e.what() << "\n";
    }

    // ── Крок 3: Перевірка виходу за межі масиву ──────────────
    std::cout << "\n--- Крок 3: Вихід за межі масиву ---\n";
    try {
        Vect b(5);
        b[0] = 10; b[1] = 20; b[2] = 30; b[3] = 40; b[4] = 50;
        b.Print();
        std::cout << "Спроба звернутись до b[10]...\n";
        b[10] = 99;   // Вихід за межі → виняток
    }
    catch (const VectException& e) {
        std::cerr << "ПЕРЕХОПЛЕНО: " << e.what() << "\n";
    }

    // ── Крок 4: Перехоплення в конструкторі (розмір = 0) ────
    std::cout << "\n--- Крок 4: Конструктор з розміром 0 ---\n";
    try {
        Vect c(0);
    }
    catch (const VectException& e) {
        std::cerr << "ПЕРЕХОПЛЕНО з конструктора: " << e.what() << "\n";
    }

    // ── Крок 5: Демонстрація Destroy() у деструкторі ────────
    std::cout << "\n--- Крок 5: Деструктор з Destroy() ---\n";
    {
        Vect d(4);
        d[0] = 7; d[1] = 8; d[2] = 9; d[3] = 10;
        d.Print();
        // ~Vect() викличеться автоматично при виході з блоку
    }

    // ── Крок 6: Xhandler — кілька типів виняткових ситуацій ─
    std::cout << "\n--- Крок 6: Xhandler — різні типи виняткових ситуацій ---\n";
    Xhandler(1);
    Xhandler(2);
    Xhandler(0);
    Xhandler(3);

    // ── Крок 7: catch(...) — перехоплення всього ─────────────
    std::cout << "\n--- Крок 7: catch(...) — перехоплення будь-якого типу ---\n";
    try {
        throw 3.14;   // double — нестандартний тип
    }
    catch (int i)    { std::cout << "int: " << i << "\n"; }
    catch (...)      { std::cout << "catch(...): перехоплено невідомий виняток (double 3.14)\n"; }

    std::cout << "\n=== Програма завершена нормально ===\n";
    return 0;
}
